/**
 * 
 */
package cs.tcd.ie;

import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.util.HashMap;
import tcdIO.*;

/**
 *
 * Client class
 * 
 * An instance accepts user input 
 *
 */
public class Enduser extends Node {

	static final String HOSTNAME = "localhost";	
	static final int PORT_BASE = 40000;
	static final int[] userPorts = {40001,40002,40003,40004,40005,40006};
	static final int[] connectedRouters = {50000,50001,50002,50003,50004,50005};
	
	Terminal terminal;
	InetSocketAddress routerAddress;
	int source;
	/**
	 * Constructor
	 * 	 
	 * Attempts to create socket at given port and create an InetSocketAddress for the destinations
	 */
	Enduser(Terminal terminal, String dstHost, int routerConnection, int srcPort) {
		try {
			this.source = srcPort;
			this.terminal= terminal;
			routerAddress= new InetSocketAddress(dstHost, routerConnection);		
			terminal.println("Connected to router at " + routerConnection);
			terminal.println("Port number: " + this.source);		
			socket= new DatagramSocket(source);
			listener.go();
		
		}
		catch(java.lang.Exception e) {e.printStackTrace();}
	}

	
	/**
	 * Assume that incoming packets contain a String and print the string.
	 */
	public synchronized void onReceipt(DatagramPacket packet) {
		StringContent content= new StringContent(packet);
		
		String payload = content.toString();
		int origin = Integer.parseInt(payload.substring(0, 5));
		payload = (payload.split("-"))[3];
		//The position of they payload is stored after LIST_START string
		payload = payload.split(LIST_START)[0];
		terminal.print("\n"+"Incoming packet from user "+ (origin-PORT_BASE) + ":\n" + payload + "\nString to send: ");

		listener.go();
	}

	
	/**
	 * Sender Method
	 * 
	 */
	public void start() throws Exception {
		
		DatagramPacket packet= null;

		byte[] payload= null;
		byte[] header= null;
		byte[] buffer= null;
		
		
		
			payload= (terminal.readString("String to send: ")+ LIST_START + terminal.readInt("Receiver:")).getBytes();
			header= new byte[PacketContent.HEADERLENGTH];
			buffer= new byte[header.length + payload.length];
			System.arraycopy(header, 0, buffer, 0, header.length);
			System.arraycopy(payload, 0, buffer, header.length, payload.length);
		
			packet= new DatagramPacket(buffer, buffer.length, routerAddress);
			socket.send(packet);
			terminal.println("Packet sent");
	
	}


	/**
	 * A function that is identical to a typical main function
	 * which is called when a new thread is made
	 * 
	 * @param userId - a pre-configured unique ID 
	 */
	public static void init(int userId) {
		try {					
			Terminal terminal= new Terminal("Enduser " + userId);			
			boolean running = true;
			Enduser user = new Enduser(terminal, HOSTNAME, connectedRouters[userId-1], userPorts[userId-1]);
			while(running){
				user.start();
			}
		} catch(java.lang.Exception e) {e.printStackTrace();}
	}
}
