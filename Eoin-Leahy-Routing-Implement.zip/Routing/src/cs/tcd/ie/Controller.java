package cs.tcd.ie;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.HashMap;
import java.net.InetSocketAddress;
import java.util.LinkedList;
import java.util.Random;

import tcdIO.Terminal;

public class Controller extends Node {

	static final int CONTROLLER_PORT = 30000;

	static final String HOSTNAME = "local host";

	static final int ROUTER_ONE = 50000;
	static final int ROUTER_TWO = 50001;
	static final int ROUTER_THREE = 50002;
	static final int ROUTER_FOUR = 50003;
	static final int ROUTER_FIVE = 50004;
	static final int ROUTER_SIX = 50005;
	static final int ROUTER_SEVEN = 50006;
	static final int ROUTER_EIGHT = 50007;
	static final int ROUTER_NINE = 50008;
	static final int ROUTER_TEN = 50009;

	static final int[] routerPortList = { ROUTER_ONE, ROUTER_TWO, ROUTER_THREE, ROUTER_FOUR, ROUTER_FIVE, ROUTER_SIX,
			ROUTER_SEVEN, ROUTER_EIGHT, ROUTER_NINE, ROUTER_TEN };
	static final int[] userList = { 40001, 40002, 40003, 40004, 40005, 40006 };
	
	// This is the list of sub-connections for each router
	/*	
	 *  Router ||	    Connections List      |	User Connection
	 * --------||-----------------------------|-------
	 * Router1 || Router2 | Router7 |		  | User1
	 * Router2 || Router1 | Router9 | 		  | User2
	 * Router3 || Router9 | Router4 |		  | User3
	 * Router4 || Router3 | Router10|         | User4
	 * Router5 || Router6 | Router10|		  | User5
	 * Router6 || Router5 | Router7 |         | User6
	 * Router7 || Router6 | Router1 | Router8 |			
	 * Router8 || Router10| Router7 | Router9 | 		
	 * Router9 || Router2 | Router3 | Router8 |         
	 * Router10|| Router5 | Router8 | Router4 |         
	*/
	 

	static final int[] router1Ports = { ROUTER_TWO, ROUTER_SEVEN, 40001 };
	static final int[] router2Ports = { ROUTER_ONE, ROUTER_NINE, 40002 };
	static final int[] router3Ports = { ROUTER_NINE, ROUTER_FOUR, 40003 };
	static final int[] router4Ports = { ROUTER_THREE, ROUTER_TEN, 40004 };
	static final int[] router5Ports = { ROUTER_SIX, ROUTER_SEVEN, 40005 };
	static final int[] router6Ports = { ROUTER_FIVE, ROUTER_SEVEN, 40006 };
	static final int[] router7Ports = { ROUTER_SIX, ROUTER_ONE, ROUTER_EIGHT };
	static final int[] router8Ports = { ROUTER_SEVEN, ROUTER_NINE, ROUTER_TEN };
	static final int[] router9Ports = { ROUTER_TWO, ROUTER_THREE, ROUTER_EIGHT };
	static final int[] router10Ports = { ROUTER_FIVE, ROUTER_EIGHT, ROUTER_FOUR };

	static HashMap<Integer, int[]> mappedRouterPorts = new HashMap<Integer, int[]>();
	static {
		mappedRouterPorts.put(ROUTER_ONE, router1Ports);
		mappedRouterPorts.put(ROUTER_TWO, router2Ports);
		mappedRouterPorts.put(ROUTER_THREE, router3Ports);
		mappedRouterPorts.put(ROUTER_FOUR, router4Ports);
		mappedRouterPorts.put(ROUTER_FIVE, router5Ports);
		mappedRouterPorts.put(ROUTER_SIX, router6Ports);
		mappedRouterPorts.put(ROUTER_SEVEN, router7Ports);
		mappedRouterPorts.put(ROUTER_EIGHT, router8Ports);
		mappedRouterPorts.put(ROUTER_NINE, router9Ports);
		mappedRouterPorts.put(ROUTER_TEN, router10Ports);
	}

	int source;
	Terminal terminal;

	Controller(Terminal terminal, String host, int srcPort) {
		try {

			this.terminal = terminal;
			this.source = srcPort;
			socket = new DatagramSocket(source);
			listener.go();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public synchronized void onReceipt(DatagramPacket packet) {
		try {

			StringContent content = new StringContent(packet);
			String payload = content.toString();

			terminal.println("Request from " + packet.getPort());

			String[] payloadArray = payload.split(LIST_START);
			int originPort = Integer.parseInt(payloadArray[1]);

			//This determines the destination port
			int endPort = 0;
			switch (payloadArray[0]) {
			case "1":
				endPort = userList[0];
				break;
			case "2":
				endPort = userList[1];
				break;
			case "3":
				endPort = userList[2];
				break;
			case "4":
				endPort = userList[3];
				break;
			case "5":
				endPort = userList[4];
				break;
			case "6":
				endPort = userList[5];
				break;
			default:
				endPort = originPort;
			}

			String responseString = createBuffer(1, originPort, generateRoute(originPort, packet.getPort(), endPort), "");
			terminal.println(responseString.split("-")[2]);
			DatagramPacket response = (new StringContent(responseString)).toDatagramPacket();
			response.setSocketAddress(packet.getSocketAddress());
			terminal.println("Route info sent");
			socket.send(response);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public synchronized void start() throws Exception {
		terminal.println("Port Number: " + source + "\nAwaiting incoming packet...");

		this.wait();
	}
	
	/*
	 *	The main function
	 */

	public static void init() {
		try {
			Terminal terminal = new Terminal("Controller");
			Controller controller = new Controller(terminal, HOSTNAME, CONTROLLER_PORT);
			boolean runnning = true;
			while (runnning) {
				controller.start();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	/*
	 * A method which generates a route that the packet follows. A somewhat
	 * dynamic route is returned by choosing a random port from a list of
	 * current ports without the previous. There is a check in place to ensure
	 * that the same port won't show up twice or that there is no loops in the
	 * route. The while loop will terminate if the destination port shows up in
	 * the list of ports that the current port can connect to.
	 * 
	 * @param int previousPort - the original port, iteratively changes to be
	 * the previous currentPort.
	 * 
	 * @param int currentPort - the port of which you are checking the
	 * connections of
	 * 
	 * @param int dstPort - The destination port
	 * 
	 * @return int[] route - The route that the packet will follow
	 */

	public static int[] generateRoute(int previousPort, int currentPort, int dstPort) {
		int[] route = null;
		boolean routeFound = false;

		Random rand = new Random();

		ArrayList<Integer> routeList = new ArrayList<>();
		while (!routeFound) {

			int[] currentPortList = mappedRouterPorts.get(currentPort);

			/*
			 * Fixes the list to only contain the ports without the previous
			 * port or the user ports unless it is the destionation port
			 */
			ArrayList<Integer> properList = new ArrayList<>();
			for (int index = 0; index < currentPortList.length; index++) {
				if ((previousPort != currentPortList[index] && currentPortList[index] > 49999)
						|| currentPortList[index] == dstPort) {
					properList.add(currentPortList[index]);
				}

			}

			/*
			 * If the current port list contains the destionation port we can
			 * terminate the loop as we have found the correct route
			 */
			if (isValidConnection(dstPort, properList))
				routeFound = true;

			routeList.add(currentPort);
			int randIndex = rand.nextInt(2);
			previousPort = currentPort;
			if (randIndex >= properList.size())
				randIndex = 0;
			currentPort = properList.get(randIndex);

			/*
			 * If the same port shows up twice then it means we have a loop so
			 * the route will remove the ports from the route until we get to the
			 * index of the 1st copy of the duplicate.
			 */
			if (routeList.contains(currentPort)) {
				boolean listFixed = false;
				int dupeIndex = routeList.indexOf(currentPortList);
				int counter = routeList.size() - 1;
				while (!listFixed) {
					routeList.remove(counter);
					counter--;
					if (counter == dupeIndex)
						listFixed = true;
				}
			}
		}

		/*
		 * Converting from ArrayList to int array
		 */
		route = new int[routeList.size() + 1];
		for (int i = 0; i < routeList.size(); i++) {
			route[i] = routeList.get(i);
		}
		route[route.length - 1] = dstPort;
		return route;
	}
}
