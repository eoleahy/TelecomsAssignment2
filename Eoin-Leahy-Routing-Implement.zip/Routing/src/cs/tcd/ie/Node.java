package cs.tcd.ie;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;

public abstract class Node {
	static final int PACKETSIZE = 65536;
	static final String LIST_START = ":<";
	static final String LIST_END= ">:";

	DatagramSocket socket;
	Listener listener;
	CountDownLatch latch;
	
	Node() {
		latch= new CountDownLatch(1);
		listener= new Listener();
		listener.setDaemon(true);
		listener.start();
	}
	
	
	public abstract void onReceipt(DatagramPacket packet);
	
	
	/*
	 * Creates a buffer which is put into the packet
	 * 
	 * @param int rule - the rule of the packet - It is 
	 * 1 if there exists a rule or 0 otherwise
	 * @param int src - The source port
	 * @param int[] path - The path which the packet will follow
	 * @param String payload - The message of the packet
	 * 
	 *  @return String buffer - a string representation of the buffer of a packet
	 */
	public static String createBuffer(int rule, int src, int[] path, String payload){
		String buffer = (src + "-" + rule + "-" + toString(path) + "-" + payload);	
		return buffer;
	}
	/*
	 * Converts an int array to a string
	 * 
	 * @param int[] o - the aray you want to convert
	 * 
	 * @return String representation to the array
	 */	
	public static String toString(int[] o) {

		String arrayString = LIST_START;
		for (int i = 0; i < o.length; i++) {


			if(i<o.length-1)
				arrayString += o[i] + ",";
			else
				arrayString += o[i];
		}
		arrayString += LIST_END;
		return arrayString;
	}
	/*
	 * A method which checks if a connection is valid by comparing a port with a
	 * list of ports
	 * 
	 * @param int currentPort - The port you are comparing
	 * 
	 * @param ArrayList <Integer> portList - The list you are checking through
	 *
	 * @return true - if the port is an element of the list
	 *
	 */
	public static boolean isValidConnection(int currentPort, ArrayList<Integer> portList) {
		if (portList.contains(currentPort))
			return true;
		else
			return false;
	}
	/*
	 * Checks if the packet has a rule
	 * 
	 * returns true if the value in position 6 is equal to 1
	 */

	public static boolean hasRule(DatagramPacket packet) {
		try {
			String payload = new StringContent(packet).toString();

			if (payload.substring(6, 7).equals("1"))
				return true;

			else
				return false;
		} catch (java.lang.StringIndexOutOfBoundsException e) {
			return false;
		}
	}
	
	/**
	 *
	 * Listener thread
	 * 
	 * Listens for incoming packets on a datagram socket and informs registered receivers about incoming packets.
	 */
	class Listener extends Thread {
		
		/*
		 *  Telling the listener that the socket has been initialized 
		 */
		public void go() {
			latch.countDown();
		}
		
		/*
		 * Listen for incoming packets and inform receivers
		 */
		public void run() {
			try {
				latch.await();
				// Endless loop: attempt to receive packet, notify receivers, etc
				while(true) {
					DatagramPacket packet = new DatagramPacket(new byte[PACKETSIZE], PACKETSIZE);
					socket.receive(packet);

					onReceipt(packet);
				}
			} catch (Exception e) {if (!(e instanceof SocketException)) e.printStackTrace();}
		}
	}
}
