package cs.tcd.ie;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.util.ArrayList;

import tcdIO.Terminal;

public class Router extends Node {

	static final int CONTROLLER_PORT = 30000;
	static final int ROUTER_ONE = 50000;
	static final int ROUTER_TWO = 50001;
	static final int ROUTER_THREE = 50002;
	static final int ROUTER_FOUR = 50003;
	static final int ROUTER_FIVE = 50004;
	static final int ROUTER_SIX = 50005;
	static final int ROUTER_SEVEN = 50006;
	static final int ROUTER_EIGHT = 50007;
	static final int ROUTER_NINE = 50008;
	static final int ROUTER_TEN = 50009;

	static final String HOSTNAME = "localhost";

	static final int[] routerPortList = { 50000, 50001, 50002, 50003, 50004, 50005, 50006, 50007, 50008, 50009 };

	// This is the list of sub-connections for each router
	/*	
	 *  Router ||	    Connections List      |	User Connection
	 * --------||-----------------------------|-------
	 * Router1 || Router2 | Router7 |		  | User1
	 * Router2 || Router1 | Router9 | 		  | User2
	 * Router3 || Router9 | Router4 |		  | User3
	 * Router4 || Router3 | Router10|         | User4
	 * Router5 || Router6 | Router10|		  | User5
	 * Router6 || Router5 | Router7 |         | User6
	 * Router7 || Router6 | Router1 | Router8 |			
	 * Router8 || Router10| Router7 | Router9 | 		
	 * Router9 || Router2 | Router3 | Router8 |         
	 * Router10|| Router5 | Router8 | Router4 |         
	*/
	
	static final int[] router1Ports = { ROUTER_TWO, ROUTER_SEVEN, 40001 };
	static final int[] router2Ports = { ROUTER_ONE, ROUTER_NINE, 40002 };
	static final int[] router3Ports = { ROUTER_NINE, ROUTER_FOUR, 40003 };
	static final int[] router4Ports = { ROUTER_THREE, ROUTER_TEN, 40004 };
	static final int[] router5Ports = { ROUTER_SIX, ROUTER_SEVEN, 40005 };
	static final int[] router6Ports = { ROUTER_FIVE, ROUTER_SEVEN, 40006 };
	static final int[] router7Ports = { ROUTER_SIX, ROUTER_ONE, ROUTER_EIGHT };
	static final int[] router8Ports = { ROUTER_SEVEN, ROUTER_NINE, ROUTER_TEN };
	static final int[] router9Ports = { ROUTER_TWO, ROUTER_THREE, ROUTER_EIGHT };
	static final int[] router10Ports ={ ROUTER_FIVE, ROUTER_EIGHT, ROUTER_FOUR };

	// Array of router port array
	static int[] routerConnectionsArray[] = { router1Ports, router2Ports, router3Ports, router4Ports, router5Ports,
			router6Ports, router7Ports, router8Ports, router9Ports, router10Ports };

	static InetSocketAddress controllerAddress;
	int srcPort;
	static int[] routerConnections;

	ArrayList<DatagramPacket> stalledPackets = new ArrayList<DatagramPacket>();

	/*
	 * 
	 */
	Router(int port, int[] routerConnections) {
		try {
			this.srcPort = port;
			this.routerConnections = routerConnections;

			controllerAddress = new InetSocketAddress(HOSTNAME, CONTROLLER_PORT);
			socket = new DatagramSocket(port);
			listener.go();

		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Assume that incoming packets contain a String and print the string.
	 */
	public void onReceipt(DatagramPacket packet) {
		try {
			int originPort = packet.getPort();

			StringContent content = new StringContent(packet);
			String contentString = content.toString();
			DatagramPacket response = null;

			// Communication from an enduser
			if (originPort != CONTROLLER_PORT) {

				// Check if the packet has a rule
				if (hasRule(packet)) {

					// If it has a rule it is processed and sent on
					String[] portListArray = contentString.split(LIST_START);

					portListArray = portListArray[1].split(LIST_END);
					String portList = portListArray[0];

					int nextPort;
					if (portList.length() > 5) {
						nextPort = Integer.parseInt(portList.substring(0, 5));
						portList = portList.substring(6); // Shifting the route
															// list over so the
															// first port is the
															// next
					} else
						nextPort = Integer.parseInt(portList);

					String[] components = contentString.split("-");
					contentString = components[0] + "-" + components[1] + "-" + LIST_START + portList + LIST_END + "-"
							+ components[3];

					content = new StringContent(contentString);
					response = content.toDatagramPacket();
					response.setSocketAddress(new InetSocketAddress(HOSTNAME, nextPort));
					socket.send(response);
				}

				else {

					// Adding the packet to a temporary array so it can be
					// pulled off later
					stalledPackets.add(packet);
					response = (new StringContent(contentString.split(LIST_START)[1] + LIST_START + packet.getPort()))
							.toDatagramPacket();
					response.setSocketAddress(controllerAddress);

					socket.send(response);
				}
			}

			// Communication from controller
			else {

				response = stalledPackets.get(0);
				stalledPackets.remove(0);

				// Reconstructing the packet
				String responsePayload = content.toString() + new StringContent(response).toString();
				int destPort = Integer.parseInt(responsePayload.substring(10, 15));
				response = (new StringContent(responsePayload)).toDatagramPacket();
				response.setSocketAddress(new InetSocketAddress(HOSTNAME, destPort));
				socket.send(response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public synchronized void start() throws Exception {

		this.wait();
	}

	/*
	 * The main function which launches the routers
	 * 
	 * @param int routerId - A unique id for the router that is pre-configured
	 * in the OpenFLowRouting class
	 */
	public static void init(int routerId) {
		try {
			(new Router(routerPortList[routerId - 1], routerConnectionsArray[routerId - 1])).start();
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}
	}

	
}