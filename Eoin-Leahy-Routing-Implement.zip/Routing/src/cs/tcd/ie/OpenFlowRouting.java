package cs.tcd.ie;
/**
 * 
 * A class that is the main runnable class of 
 * this project. Creates a unique thread for 
 * each Router, Enduser and the Controller
 *
 */

public class OpenFlowRouting implements Runnable {

	static volatile int[] userIds = {1,2,3,4,5,6};
	static volatile int[] routerIds = {1,2,3,4,5,6,7,8,9,10};
	
	
	public static void main(String[] args) {
		
		
		new Thread(new OpenFlowRouting() {
			public void run(){
				Controller.init();
			}
		}).start();
			System.out.println("Controller launched");
		
		//Launching 10 Router threads
		
		new Thread(new OpenFlowRouting() {
			public void run(){
				Router.init(routerIds[0]);
			}
		}).start();
		
		new Thread(new OpenFlowRouting() {
			public void run(){
				Router.init(routerIds[1]);
			}
		}).start();
			
		new Thread(new OpenFlowRouting() {
			public void run(){
				Router.init(routerIds[2]);
			}
		}).start();
		
		new Thread(new OpenFlowRouting() {
			public void run(){
				Router.init(routerIds[3]);
			}
		}).start();
		
		new Thread(new OpenFlowRouting() {
			public void run(){
				Router.init(routerIds[4]);
			}
		}).start();
		
		new Thread(new OpenFlowRouting() {
			public void run(){
				Router.init(routerIds[5]);
			}
		}).start();
		
		new Thread(new OpenFlowRouting() {
			public void run(){
				Router.init(routerIds[6]);
			}
		}).start();
		
		new Thread(new OpenFlowRouting() {
			public void run(){
				Router.init(routerIds[7]);
			}
		}).start();
		
		new Thread(new OpenFlowRouting() {
			public void run(){
				Router.init(routerIds[8]);
			}
		}).start();
		
		new Thread(new OpenFlowRouting() {
			public void run(){
				Router.init(routerIds[9]);
			}
		}).start();
		
		//Launching 6 user threads
		
		new Thread(new OpenFlowRouting() {
			public void run(){
				Enduser.init(userIds[0]);
			}
		}).start();
		
		new Thread(new OpenFlowRouting() {
			public void run(){
				Enduser.init(userIds[1]);
			}
		}).start();
		
		new Thread(new OpenFlowRouting() {
			public void run(){
				Enduser.init(userIds[2]);
			}
		}).start();
		
		new Thread(new OpenFlowRouting() {
			public void run(){
				Enduser.init(userIds[3]);
			}
		}).start();
		
		new Thread(new OpenFlowRouting() {
			public void run(){
				Enduser.init(userIds[4]);
			}
		}).start();
		
		new Thread(new OpenFlowRouting() {
			public void run(){
				Enduser.init(userIds[5]);
			}
		}).start();
		
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
}
